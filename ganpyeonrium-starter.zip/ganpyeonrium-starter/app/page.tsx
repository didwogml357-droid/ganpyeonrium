'use client';
import { useMemo, useState } from 'react';

type Product = { id:number; name:string; category:string; price:number; description:string; badge:string; image:string; affiliateUrl:string; featured:boolean };
const initial: Product[] = [
 {id:1,name:'싱크대 슬라이딩 수납장',category:'간편리빙',price:18900,description:'좁은 싱크대 아래 공간을 효율적으로 정리하는 추천 아이템입니다.',badge:'공간 활용',image:'https://placehold.co/700x500/F0F0E9/172B35?text=Kitchen+Storage',affiliateUrl:'#',featured:true},
 {id:2,name:'전동 청소솔',category:'간편리빙',price:23900,description:'욕실과 주방 청소 시간을 줄여주는 생활 아이템입니다.',badge:'청소 간편템',image:'https://placehold.co/700x500/B9D9D5/172B35?text=Electric+Brush',affiliateUrl:'#',featured:true},
 {id:3,name:'미니 라벨 프린터',category:'간편테크',price:32900,description:'수납용기와 케이블에 이름표를 붙여 정리하기 좋습니다.',badge:'정리의 완성',image:'https://placehold.co/700x500/F0F0E9/172B35?text=Mini+Label+Printer',affiliateUrl:'#',featured:true},
 {id:4,name:'모션센서 LED 조명',category:'간편테크',price:15900,description:'움직임을 감지해 어두운 공간을 자동으로 밝혀줍니다.',badge:'생활 편의',image:'https://placehold.co/700x500/B9D9D5/172B35?text=Motion+LED',affiliateUrl:'#',featured:false}
];
const money=(n:number)=>new Intl.NumberFormat('ko-KR').format(n)+'원';
export default function Home(){
 const [items,setItems]=useState<Product[]>(initial); const [category,setCategory]=useState('전체'); const [query,setQuery]=useState(''); const [sort,setSort]=useState('추천순'); const [selected,setSelected]=useState<Product|null>(null);
 const filtered=useMemo(()=>items.filter(p=>(category==='전체'||p.category===category)&&(p.name+p.description).toLowerCase().includes(query.toLowerCase())).sort((a,b)=>sort==='낮은 가격순'?a.price-b.price:sort==='높은 가격순'?b.price-a.price:Number(b.featured)-Number(a.featured)),[items,category,query,sort]);
 return <main><header className="top"><a className="logo" href="#">간편리엄<span>GANPYEONRIUM</span></a><nav><a href="#products">추천 상품</a><a href="#about">브랜드 소개</a><a href="/admin">관리자</a></nav></header>
 <section className="hero"><div className="hero-copy"><p className="eyebrow">SMART PICKS FOR EVERYDAY</p><h1>귀찮음은 줄이고,<br/><em>만족은 높이고.</em></h1><p>일상을 더 간편하게 만드는 작지만 확실한 발견.<br/>간편리엄이 직접 고른 생활 아이템을 만나보세요.</p><a className="cta" href="#products">추천 아이템 보기 <b>↗</b></a></div><div className="hero-art"><div className="orb">G</div><span className="art-tag">EASY LIFE, BETTER CHOICE</span></div></section>
 <section className="intro" id="about"><span>OUR CURATION</span><h2>매일 쓰는 물건일수록,<br/>더 똑똑하게 선택하도록.</h2><p>실용성, 가격, 사용 편의성을 기준으로 일상에 도움이 되는 아이템을 소개합니다.</p></section>
 <section className="products" id="products"><div className="section-head"><div><span className="eyebrow">THE EDIT</span><h2>오늘의 추천 아이템</h2></div><span className="count">{filtered.length} ITEMS</span></div>
 <div className="toolbar"><div className="tabs">{['전체','간편리빙','간편테크'].map(c=><button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div><div className="filters"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="상품 검색"/><select value={sort} onChange={e=>setSort(e.target.value)}><option>추천순</option><option>낮은 가격순</option><option>높은 가격순</option></select></div></div>
 <div className="grid">{filtered.map(p=><article className="product" key={p.id}><button className="image-button" onClick={()=>setSelected(p)}><img src={p.image} alt={p.name}/><span>{p.badge}</span></button><div className="product-info"><small>{p.category}</small><h3>{p.name}</h3><p>{p.description}</p><div className="product-bottom"><strong>{money(p.price)}</strong><button onClick={()=>setSelected(p)}>자세히 보기 ↗</button></div></div></article>)}</div>
 </section><footer><div className="logo">간편리엄<span>GANPYEONRIUM</span></div><p>일상을 간편하게, 생활은 더 프리미엄하게.</p><small>간편리엄은 쿠팡 파트너스 활동을 통해 일정액의 수수료를 제공받을 수 있습니다.<br/>상품 가격과 재고는 판매처 사정에 따라 변경될 수 있습니다.</small></footer>
 {selected&&<div className="modal-bg" onClick={()=>setSelected(null)}><div className="modal" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}>×</button><img src={selected.image} alt={selected.name}/><small>{selected.category} · {selected.badge}</small><h2>{selected.name}</h2><p>{selected.description}</p><strong>{money(selected.price)}</strong><a className="cta" href={selected.affiliateUrl} target="_blank" rel="noreferrer">쿠팡에서 상품 확인하기 ↗</a><small className="notice">쿠팡 파트너스 활동을 통해 일정액의 수수료를 제공받을 수 있습니다.</small></div></div>}
 </main>
}
